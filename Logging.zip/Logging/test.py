import logging
logging.basicConfig(filename='test.log',level= logging.INFO)     #creating file
logging.info("this is my very first code for logging")     #passing information
l = [1,2,3,4,5,6,7,8,9]
for i in l:
    if i==2:
        logging.info(l)

# log level ----> debug(10),warnings(30),error(40),critical(50),info(10)
# root ---> user

logging.shutdown()  # terminate the logger