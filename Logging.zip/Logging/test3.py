import logging
logging.basicConfig(filename="test3.log", level= logging.INFO, format='%(levelname)s %(asctime)s %(message)s')
def divide(a,b):
    logging.info("the number entered by user is %s and %s", a,b)
    try:
        logging.info("we are unto function")
        div = a/b
        logging.info("result of code is %s ", div)
        return div
    except Exception as e:
        logging.exception(e)

print(divide(3,9))
